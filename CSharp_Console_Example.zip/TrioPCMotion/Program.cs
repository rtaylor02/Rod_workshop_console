﻿using System;
using TrioMotion.TrioPC_NET;

namespace TrioPCMotion
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Create an instance of MyController
            MyController myController = new MyController();
            myController.ConnectToController("127.0.0.1");

            // Enter test code here



            Console.ReadLine();
        }
    }
    internal class MyController : TrioPC
    {
        internal void ConnectToController(string ip_address)
        {
            this.SetHost(ip_address);

            if (this.Open(PortType.Ethernet, PortId.EthernetREMOTE))
            {
                Console.WriteLine("Connected to contoller on ip: {0}", this.HostAddress);
            }
            else
            {
                Console.WriteLine("Error in connecting to ip: {0}", this.HostAddress);
            }
        }
    }
}

#region SetTable
//double[] valArray = { 1.2, 2.3, 3.4, 4.5, 5.6, 6.7 };
//myController.SetTable(0, valArray);
//myController.SetTable(10, 5, valArray);
//myController.SetTable(20, valArray, 2, 4);
#endregion

#region DisplayTableValues
//myController.DisplayTableValues(10);

//internal void DisplayTableValues(int startingIndex)
//{
//    double[] temp = new double[1000];

//    if (this.IsOpen(PortId.EthernetREMOTE))
//    {
//        if (this.GetTable(startingIndex, ref temp))
//        {
//            for (int i = 0; i < temp.Length; i++)
//            {
//                Console.WriteLine("TABLE({0}) = {1}", (i + startingIndex), temp[i]);
//            }
//        }
//    }
//    else
//    {
//        Console.WriteLine("Not connected to controller");
//    }
//}
#endregion

#region DisplayTableValues(,)
//myController.DisplayTableValues(10, 5);

//internal void DisplayTableValues(int startingIndex, int number)
//{
//    double[] temp = new double[number];

//    if (this.IsOpen(PortId.EthernetREMOTE))
//    {
//        if (this.GetTable(startingIndex, number, ref temp))
//        {
//            for (int i = 0; i < number; i++)
//            {
//                Console.WriteLine("TABLE({0}) = {1}", (i + startingIndex), temp[i]);
//            }
//        }
//    }
//    else
//    {
//        Console.WriteLine("Not connected to controller");
//    }
//}
#endregion

#region DisplayTableValues(,,)
//myController.DisplayTableValues(10, 5, 1);

//internal void DisplayTableValues(int startingIndex, int number, int offset)
//{
//    double[] temp = new double[number];

//    if (this.IsOpen(PortId.EthernetREMOTE))
//    {
//        if (this.GetTable(startingIndex, number, offset, ref temp))
//        {
//            for (int i = 0; i < number; i++)
//            {
//                Console.WriteLine("TABLE({0}) = {1}", (i + startingIndex + (i * offset)), temp[i]);
//            }
//        }
//    }
//    else
//    {
//        Console.WriteLine("Not connected to controller");
//    }
//}
#endregion

#region DisplayAxisParameter()
//myController.DisplayAxisParameter("units", 1);

//internal void DisplayAxisParameter(string axisParameter, int axisNo)
//{
//    double temp;

//    if (this.IsOpen(PortId.EthernetREMOTE))
//    {
//        if (this.GetAxisVariable(axisParameter.ToUpper(), axisNo, out temp))
//        {
//            Console.WriteLine("Axis {0} {1} = {2}", axisNo, axisParameter.ToUpper(), temp);
//        }
//        else
//        {
//            Console.WriteLine("Invalid axis parameter name");
//        }

//    }
//    else
//    {
//        Console.WriteLine("Not connected to controller");
//    }
//}
#endregion

#region In()
//double binarySum;
//int startIndex = 0, endIndex = 15;

//myController.In(startIndex, endIndex, out binarySum);
//Console.WriteLine("Binary sum input value = {0}", binarySum);
#endregion

#region SetVr()
//internal void tripleVRs(int startingIndex, int number)
//{
//    double temp;

//    Console.WriteLine("Initialising VRs to tripple the original values ...");

//    if (this.IsOpen(PortId.EthernetREMOTE))
//    {
//        for (int index = 0; index < number; index++)
//        {
//            this.GetVr((index + startingIndex), out temp);

//            temp = 3 * temp;

//            this.SetVr((index + startingIndex), temp);
//        }
//    }
//    else
//    {
//        Console.WriteLine("Not connected to controller");
//    }
//}
#endregion

#region DisplayVRs()
//// Get initial VR index to display
//Console.WriteLine("Enter VR start index: ");
//int startVR = Convert.ToInt32(Console.ReadLine());

//// Get total VR index to display
//Console.WriteLine("Enter total VRs to fetch");
//int totalVR = Convert.ToInt32(Console.ReadLine());

//myController.DisplayVRs(startVR, totalVR);


//internal void DisplayVRs(int startingIndex, int number)
//{
//    double temp;

//    Console.WriteLine("Reading VRs:");

//    if (this.IsOpen(PortId.EthernetREMOTE))
//    {
//        for (int index = 0; index < number; index++)
//        {
//            if (this.GetVr((index + startingIndex), out temp))
//            {
//                Console.WriteLine("VR({0}) = {1}", (index + startingIndex), temp);
//            }
//        }
//    }
//    else
//    {
//        Console.WriteLine("Not connected to controller");
//    }
//}
#endregion

#region SetAxisVariable()
//myController.SetAxisVariable("units", 1, 1000);

//public new void SetAxisVariable(string axisParameter, int axisNo, double value)
//{
//    if (this.IsOpen(PortId.EthernetREMOTE))
//    {
//        if (base.SetAxisVariable(axisParameter.ToUpper(), axisNo, value))
//        {
//            Console.WriteLine("Setting axis {0} parameter - {1} = {2}", axisNo, axisParameter, value);
//        }
//        else
//        {
//            Console.WriteLine("Invalid axis parameter name");
//        }
//    }
//    else
//    {
//        Console.WriteLine("Not connected to controller");
//    }
//}
#endregion
